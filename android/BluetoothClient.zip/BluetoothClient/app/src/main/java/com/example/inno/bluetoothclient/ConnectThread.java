package com.example.inno.bluetoothclient;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;

import java.io.IOException;
import java.util.UUID;

/**
 * Created by Inno on 13.11.2015.
 */
public class ConnectThread extends Thread {

    private final BluetoothSocket mmSocket;
    private final BluetoothDevice mmDevice;
    private final BluetoothAdapter mBluetoothAdapter;

    private final static UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");

    public ConnectThread(BluetoothDevice device)    {
        BluetoothSocket tmp = null;
        mmDevice = device;

        try {
            tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
        }
        catch (IOException e)   {
            Log.d("debug", "construct failed");
        }
        mmSocket = tmp;

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    public void run()   {
        mBluetoothAdapter.cancelDiscovery();

        try {
            mmSocket.connect();
            Log.d("debug", "connection succeed");
            ConnectedThread connectedThread = new ConnectedThread(mmSocket);
            connectedThread.start();
        }
        catch (IOException connectException)    {
            Log.d("debug", "connection failed : " + connectException.getMessage());
            try {
                mmSocket.close();
            }
            catch (IOException closeException)  {
            }
            return;
        }
    }

    public void cancel()    {
        try {
            mmSocket.close();
        } catch (IOException e) {}
    }

}
