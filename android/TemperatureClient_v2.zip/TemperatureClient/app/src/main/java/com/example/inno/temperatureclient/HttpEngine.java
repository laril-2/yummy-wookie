package com.example.inno.temperatureclient;

import org.json.*;
import java.util.ArrayList;

/**
 * Created by Inno on 6.11.2015.
 */
public class HttpEngine {

    public interface DataAvailableInterface {
        public void dataAvailable();
    }

    private ArrayList<TestNode> data;
    private int responseCode;
    private DataAvailableInterface uiCallback;
    private boolean inProgress;

    public HttpEngine(DataAvailableInterface callback)  {
        this.uiCallback = callback;
        this.data = new ArrayList<TestNode>();
        this.responseCode = -1;
        this.inProgress = false;
    }

    public ArrayList<TestNode> getData()   {
        return this.data;
    }

    public int getResponseCode()    {
        return this.responseCode;
    }

    public boolean getRequest(String url)  {
        if (this.inProgress)    {
            return false;
        }
        this.inProgress = true;
        this.data.clear();
        GetRequest req = new GetRequest(url, this);
        Thread getThread = new Thread(req);
        getThread.start();
        return true;
    }

    public void success(int responseCode, String data)    {
        this.inProgress = false;
        this.responseCode = responseCode;

        try {
            this.data.clear();
            JSONObject obj = new JSONObject(data);

            JSONArray results = obj.getJSONArray("result");
            for (int i = 0; i < results.length(); i++)  {
                int id = results.getJSONObject(i).getInt("id");
                String value = results.getJSONObject(i).getString("value");
                this.data.add(new TestNode(id, value));
            }

        } catch (JSONException e)   {
            this.data.clear();
        }


        this.uiCallback.dataAvailable();
    }

    public void failure(String msg) {
        this.inProgress = false;
        this.responseCode = -1;
        this.data.clear();
        this.uiCallback.dataAvailable();
    }

}
