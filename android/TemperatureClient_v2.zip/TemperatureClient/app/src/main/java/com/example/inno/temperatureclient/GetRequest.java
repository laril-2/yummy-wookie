package com.example.inno.temperatureclient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Inno on 6.11.2015.
 */
public class GetRequest implements Runnable {

    private String url;
    private HttpEngine engine;

    public GetRequest(String url, HttpEngine engine)    {
        this.url = url;
        this.engine = engine;
    }

    public void run()   {
        try {
            URL url = new URL(this.url);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();

            con.setRequestMethod("GET");

            int responseCode = con.getResponseCode();
            BufferedReader buf = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String line;
            StringBuffer strBuf = new StringBuffer();
            while ((line = buf.readLine()) != null) {
                strBuf.append(line);
            }
            this.engine.success(responseCode, strBuf.toString());
        }
        catch (Exception e) {
            this.engine.failure("GetRequest failed on " + this.url + " message: " + e.getMessage());
        }
    }

}
