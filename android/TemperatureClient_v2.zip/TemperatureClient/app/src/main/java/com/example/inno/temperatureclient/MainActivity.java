package com.example.inno.temperatureclient;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, HttpEngine.DataAvailableInterface  {

    private EditText urlEditor;
    private LinearLayout dataLayout;
    private Button goButton, listButton;

    private final String preferenceKey = "aoen-4&7umx=";

    private SharedPreferences myPreferences;

    private HttpEngine engine;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        this.urlEditor = (EditText) findViewById(R.id.url);
        this.dataLayout = (LinearLayout) findViewById(R.id.data_layout);
        this.goButton = (Button) findViewById(R.id.go);
        this.listButton = (Button) findViewById(R.id.list);

        this.goButton.setOnClickListener(this);
        this.listButton.setOnClickListener(this);

        this.myPreferences = getSharedPreferences(this.preferenceKey, Context.MODE_PRIVATE);
        this.urlEditor.setText(this.myPreferences.getString(this.preferenceKey, "http://"));
        this.engine = new HttpEngine(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void toaster(String msg) {
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, msg, Toast.LENGTH_SHORT);
        toast.show();
    }

    public void onClick(View view)   {
        if (! (view instanceof Button))
            return;
        Button btn = (Button) view;
        if (btn == this.goButton)   {
            String url = this.urlEditor.getText().toString();
            if (this.engine.getRequest(url))   {
                this.toaster("Requesting data");
            }
            else    {
                this.toaster("HttpEngine busy");
            }

            Editor preferenceEditor = this.myPreferences.edit();
            preferenceEditor.putString(this.preferenceKey, url);
            preferenceEditor.commit();
        }
        else if (btn == this.listButton){
            Intent intent = new Intent(getApplicationContext(), ListActivity.class);

            int entries = this.engine.getData().size();
            String[] values = new String[entries];

            int i = 0;
            for (TestNode node : this.engine.getData()) {
                values[i] = node.id + ":" + node.value;
                i++;
            }
            intent.putExtra("values", values);

            startActivity(intent);
        }
    }

    protected void updateUI()   {
        this.toaster("STATUS " + this.engine.getResponseCode() + ": " + this.engine.getData().size() + " ENTRIES");
    }

    public void dataAvailable() {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                updateUI();
            }
        });
    }
}
