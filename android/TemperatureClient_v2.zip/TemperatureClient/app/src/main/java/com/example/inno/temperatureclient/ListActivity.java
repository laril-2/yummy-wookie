package com.example.inno.temperatureclient;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ListActivity extends AppCompatActivity {

    LinearLayout listLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        this.listLayout = (LinearLayout) findViewById(R.id.data_list_layout);
        this.listLayout.removeAllViews();

        Intent intent = getIntent();
        String[] values = intent.getStringArrayExtra("values");
        for (String value : values) {
            TextView entry = new TextView(this);
            entry.setText(value);
            entry.setTextColor(Color.parseColor("#000000"));
            entry.setBackgroundColor(Color.parseColor("#20FF20"));
            this.listLayout.addView(entry);
        }
    }

}
