package com.example.inno.temperatureclient;

/**
 * Created by Inno on 6.11.2015.
 */
public class TestNode {

    public final int id;
    public final String value;

    public TestNode(int id, String value)   {
        this.id = id;
        this.value = value;
    }

}
